Sample Application requires android appcompat library to work since we are using the runtime permissions checks for location. Permissions are required if you are running your application on marshmallow and above. 
Note: Gimbal SDK does not add any dependency on appcompat, its the Sample Application UI which requires library.

Using Eclipse
Please refer to the documentation here(Adding libraries with resources) 
Please follow all the steps included in the instructions to add the v7 appcompat library. This project requires the library which compiles against the android-23. The two important steps which includes instructions are:
***Create a library project based on the support library code
***Add the library to your application project (which is the Gimbal Sample Application)


*Create a library project based on the support library code:

Make sure you have downloaded the Android Support Library using the SDK Manager.

Create a library project and ensure the required JAR files are included in the project's build path:

Select File > Import.

Select Existing Android Code Into Workspace and click Next.

Browse to the SDK installation directory and then to the Support Library folder. For example, if you are adding the appcompat project, browse to /extras/android/support/v7/appcompat/.

Click Finish to import the project. For the v7 appcompat project, you should now see a new project titled android-support-v7-appcompat.

In the new library project(Project explorer view), expand the libs/ folder, right-click each .jar file and select Build Path > Add to Build Path. For example, when creating the the v7 appcompat project, add the android-support-v7-appcompat.jar file to the build path.

Right-click the library project folder and select Build Path > Configure Build Path.

In the Order and Export tab, check the .jar files you just added to the build path, so they are available to projects that depend on this library project. For example, the basic-sample-app project requires you to export the android-support-v7-appcompat.jar file.

Uncheck Android Dependencies.

Click OK to complete the changes.

You now have a library project for your selected Support Library that you can use with one or more application projects.

*Add the library to your application project:

In the Project Explorer, right-click your project and select Properties.

In the category panel on the left side of the dialog, select Android.

In the Library pane, click the Add button.

Select the library project and click OK. For example, the appcompat project should be listed as android-support-v7-appcompat.

In the properties window, click OK.

NOTE: In some cases we have seen that the appcompat library which you import into eclipse project is not compiling even though you have taken the latest version (23) of appcompat from SDK manager.
1) One of the fixes is make sure the project.properties file is pointing to the right android version and set the target=android-23

NOTE: Gimbal no longer supports posting communication/instant notifications for versions below Android 3.0. Refer to the CommunicationManager documentation for more information. https://docs.gimbal.com/android/v2/devguide.html#communication_manager